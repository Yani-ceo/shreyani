package com.example.vc;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.widget.Button;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;

import androidx.appcompat.app.AppCompatActivity;

import java.io.OutputStream;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    BluetoothAdapter bluetoothAdapter;
    BluetoothSocket socket;
    OutputStream outputStream;

    Button btnVoice;

    static final int VOICE_REQ = 1;

    UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnVoice = findViewById(R.id.btnVoice);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        connectESP32();

        btnVoice.setOnClickListener(v -> startVoice());
    }

    void connectESP32() {
        try {
            BluetoothDevice esp32 = null;
            Set<BluetoothDevice> devices = bluetoothAdapter.getBondedDevices();

            for (BluetoothDevice device : devices) {
                if (device.getName().equals("ESP32_WHEEL")) {
                    esp32 = device;
                    break;
                }
            }

            if (esp32 == null) {
                Toast.makeText(this, "ESP32 not paired", Toast.LENGTH_SHORT).show();
                return;
            }

            socket = esp32.createRfcommSocketToServiceRecord(uuid);
            socket.connect();
            outputStream = socket.getOutputStream();

            Toast.makeText(this, "ESP32 Connected", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this, "Bluetooth Error", Toast.LENGTH_SHORT).show();
        }
    }

    void startVoice() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        startActivityForResult(intent, VOICE_REQ);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == VOICE_REQ && resultCode == RESULT_OK) {
            String command = data.getStringArrayListExtra(
                    RecognizerIntent.EXTRA_RESULTS).get(0).toLowerCase();

            sendCommand(command);
        }
    }

    void sendCommand(String cmd) {
        try {
            if (cmd.contains("forward")) outputStream.write("F".getBytes());
            else if (cmd.contains("back")) outputStream.write("B".getBytes());
            else if (cmd.contains("left")) outputStream.write("L".getBytes());
            else if (cmd.contains("right")) outputStream.write("R".getBytes());
            else if (cmd.contains("stop")) outputStream.write("S".getBytes());
        } catch (Exception e) {
            Toast.makeText(this, "Send failed", Toast.LENGTH_SHORT).show();
        }
    }
}